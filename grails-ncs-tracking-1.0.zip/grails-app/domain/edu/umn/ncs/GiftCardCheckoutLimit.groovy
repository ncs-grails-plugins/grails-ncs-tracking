package edu.umn.ncs

class GiftCardCheckoutLimit {
	String role
	Integer limit
	
    static constraints = {
    }
}
