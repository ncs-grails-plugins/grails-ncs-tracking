package edu.umn.ncs

class GiftCardType {
	String description
	
    static constraints = {
    }
}
