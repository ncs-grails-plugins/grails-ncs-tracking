package edu.umn.ncs

class InstrumentStatus implements Serializable {
	String name
	String toString() { name }
    static constraints = {
    }
}
