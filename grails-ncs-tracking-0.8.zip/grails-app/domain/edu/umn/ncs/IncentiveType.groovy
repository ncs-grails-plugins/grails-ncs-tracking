package edu.umn.ncs

class IncentiveType {
	String name
	
    static constraints = {
    }
}
