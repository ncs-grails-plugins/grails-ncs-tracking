package edu.umn.ncs

class GiftCardType {
	String description
	
	String toString() { description }
 	
    static constraints = {
    }
}
